package com.juice.steps;

import java.util.Locale;

import com.github.javafaker.Faker;
import com.juice.factory.LoginPage;
import com.juice.util.Base;

import io.cucumber.java.ast.Cuando;
import io.cucumber.java.es.Dado;
import io.cucumber.java.es.Entonces;
import lombok.extern.slf4j.Slf4j;

import static org.testng.Assert.assertTrue;

@Slf4j
public class LoginSteps extends Base {

    LoginPage loginPage = new LoginPage(returnDriver());

    @Dado("que el usuario esta en la pagina de login")
    public void que_el_usuario_esta_en_la_pagina_de_login() {
        loginPage.navigateToLoginPage();
    }

    @Cuando("el usuario ingresa sus credenciales")
    public void el_usuario_ingresa_sus_credenciales() {
        loginPage.fillOutLoginForm("abc123@gmail.com","123456");
    }

    @Cuando("hace click en el botón de Log in")
    public void hace_click_en_el_botón_de_log_in() {
        loginPage.doLogin();
    }

    @Entonces("el sistema deberia mostrarle el menu de log out")
    public void el_sistema_deberia_mostrarle_el_menu_de_log_out() {
        loginPage.isSearchPageDisplayed();
    }

    @Dado("que el usuario ha iniciado sesión en su cuenta")
    public void que_el_usuario_ha_iniciado_sesión_en_su_cuenta() {
        loginPage.doLoginUser("abc123@gmail.com","123456");
    }

    @Cuando("el usuario accede a la sección de direcciones de envío")
    public void el_usuario_accede_a_la_sección_de_direcciones_de_envío() {
        loginPage.navigateToAddressPage();
    }

    @Cuando("agrega una nueva dirección de envío con detalles válidos")
    public void agrega_una_nueva_dirección_de_envío_con_detalles_válidos() {
        loginPage.clickAddressLink();
    }

    @Cuando("guarda la nueva dirección")
    public void guarda_la_nueva_dirección() {
        loginPage.doSubmitAddressForm("Perú", "casa", "96325896", "123", "Los andes 123", "Chiclayo");
    }

    @Entonces("el sistema debe mostrar un mensaje de confirmación y la dirección de envío debe estar asociada a la cuenta del usuario")
    public void el_sistema_debe_mostrar_un_mensaje_de_confirmación_y_la_dirección_de_envío_debe_estar_asociada_a_la_cuenta_del_usuario() {
        assertTrue(loginPage.isMessageDisplayed());
    }

    @Cuando("el usuario accede a la página de cambio de clave")
    public void el_usuario_accede_a_la_página_de_cambio_de_clave() {
        loginPage.navigateToChangePasswordPage();
    }

    @Cuando("el usuario accede a la sección de información de pago")
    public void el_usuario_accede_a_la_sección_de_información_de_pago() {
        loginPage.navigateToPaymentOptionPage();
    }

    @Cuando("cambia su clave actual por una nueva clave segura")
    public void cambia_su_clave_actual_por_una_nueva_clave_segura() {
        loginPage.fillOutChangePasswordForm("123456","abc123","abc123");
    }

    @Cuando("agrega una nueva tarjeta de crédito con detalles válidos")
    public void agrega_una_nueva_tarjeta_de_crédito_con_detalles_válidos() {
        loginPage.fillOutPaymentOptionsForm("new card", "3123123423423423", "4", "2080");
    }

    @Cuando("guarda los cambios")
    public void guarda_los_cambios() {
        loginPage.doSubmitChangePassword();
    }

    @Cuando("guarda la nueva tarjeta")
    public void guarda_la_nueva_tarjeta() {
        loginPage.doSubmitPaymentPassword();
    }

    @Entonces("el sistema debe mostrar un mensaje de confirmación y la clave del usuario debe actualizarse correctamente")
    public void el_sistema_debe_mostrar_un_mensaje_de_confirmación_y_la_clave_del_usuario_debe_actualizarse_correctamente() {
        assertTrue(loginPage.getMessageConfirmation().contains("Your password was successfully changed."));
    }

    @Entonces("el sistema debe mostrar un mensaje de confirmación y la tarjeta de crédito debe estar asociada a la cuenta del usuario")
    public void el_sistema_debe_mostrar_un_mensaje_de_confirmación_y_la_tarjeta_de_crédito_debe_estar_asociada_a_la_cuenta_del_usuario() {
        assertTrue(loginPage.getCardMessageConfirmation().contains("Your card ending with"));
    }
}
