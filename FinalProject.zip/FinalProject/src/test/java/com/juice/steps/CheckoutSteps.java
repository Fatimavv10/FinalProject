package com.juice.steps;

import com.juice.util.Base;

import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Dado;
import io.cucumber.java.es.Entonces;

public class    CheckoutSteps extends Base {

    @Dado("que el usuario esta en la pagina de inicio de sesion")
    public void que_el_usuario_esta_en_la_pagina_de_inicio() {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }


    @Cuando("el usuario busca y selecciona un producto")
    public void el_usuario_busca_y_selecciona_un_producto() {
    }

    @Cuando("el usuario añade el producto al carrito")
    public void el_usuario_añade_el_producto_al_carrito() {
    }

    @Entonces("el carrito debe mostrar los productos existentes")
    public void el_carrito_debe_mostrar_los_productos_existentes() {

    }

    @Dado("que he agregado un artículo")
    public void que_he_agregado_un_artículo() {
    }

    @Cuando("voy carrito completo la informacion requerida")
    public void voy_carrito_completo_la_informacion_requerida() {
    }

    @Cuando("confirmo los detalles de mi orden")
    public void confirmo_los_detalles_de_mi_orden() {
    }

    @Entonces("soy redirigido a la página de agradecimiento.")
    public void soy_redirigido_a_la_página_de_agradecimiento() {
    }
}
