package com.juice.factory;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.time.Duration;

public class LoginPage {

    WebDriver driver;

    // Object repository
    @FindBy(id = "navbarAccount")
    private WebElement accountLink;

    // Object repository
    @FindBy(id = "navbarLoginButton")
    private WebElement loginLink;

    @FindBy(name = "email")
    private WebElement emailField;

    @FindBy(name = "password")
    private WebElement passwordField;

    @FindBy(id = "loginButton")
    private WebElement loginButton;

    @FindBy(xpath = "//button[@aria-label='Show Orders and Payment Menu']")
    private WebElement orderLink;

    @FindBy(xpath = "//button[@routerlink='/address/saved']")
    private WebElement addressLink;

    @FindBy(xpath = "//button[@routerlink='/address/create']")
    private WebElement addAddressLink;

    @FindBy(id = "mat-input-43")
    private WebElement countryField;

    @FindBy(id = "mat-input-44")
    private WebElement nameField;

    @FindBy(id = "mat-input-45")
    private WebElement mobileField;

    @FindBy(id = "mat-input-46")
    private WebElement zipcodeField;

    @FindBy(id = "address")
    private WebElement addressField;

    @FindBy(id = "mat-input-48")
    private WebElement cityField;

    @FindBy(id = "submitButton")
    private WebElement submitButton;

    @FindBy(xpath = "//span[@class='mat-simple-snack-bar-content']")
    private WebElement messageText;

    @FindBy(xpath = "//button[@aria-label='Show Privacy and Security Menu']")
    private WebElement securityLink;

    @FindBy(xpath = "//button[@aria-label='Go to change password page']")
    private WebElement changePasswordLink;

    @FindBy(xpath = "//button[@routerlink='/saved-payment-methods']")
    private WebElement PaymentLink;

    @FindBy(id = "currentPassword")
    private WebElement currentPasswordField;

    @FindBy(id = "newPassword")
    private WebElement newPasswordField;

    @FindBy(id = "newPasswordRepeat")
    private WebElement newPasswordRepeatField;

    @FindBy(id = "changeButton")
    private WebElement changeButton;

    @FindBy(xpath = "//div[@class='confirmation']")
    private WebElement messageConfirmation;

    @FindBy(id = "mat-input-12")
    private WebElement nameCardField;

    @FindBy(id = "mat-input-13")
    private WebElement numberCardField;

    @FindBy(id = "mat-input-14")
    private WebElement expiryMonthField;

    @FindBy(id = "mat-input-15")
    private WebElement expiryYearField;

    @FindBy(xpath = "//span[@class='mat-simple-snackbar-action ng-star-inserted']")
    private WebElement messageCardConfirmation;

    // constructor with PageFactory for initiate all the page objects
    public LoginPage(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    public void fillOutLoginForm(String user, String pas) {
        emailField.sendKeys(user);
        passwordField.sendKeys(pas);
    }

     public void navigateToLoginPage() {
//        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        accountLink.click();
        loginLink.click();
    }

    public void doLogin() {
        loginButton.submit();
    }

    public void doLoginUser(String email, String password) {
        navigateToLoginPage();
        fillOutLoginForm(email, password);
        doLogin();
    }

    public void isSearchPageDisplayed() {
    }

    public void navigateToAddressPage() {
        accountLink.click();
        orderLink.click();
        addressLink.click();
    }

    public void clickAddressLink() {
        addAddressLink.click();
    }

    public void fillOutAddressForm(String country, String name, String mobile, String zipcode, String address, String city) {
        countryField.sendKeys(country);
        nameField.sendKeys(name);
        mobileField.sendKeys(mobile);
        zipcodeField.sendKeys(zipcode);
        addressField.sendKeys(address);
        cityField.sendKeys(city);
    }

    public void doSubmitAddressForm(String country, String name, String mobile, String zipcode, String address, String city) {
        fillOutAddressForm(country, name, mobile, zipcode, address, city);
        submitButton.submit();
    }

    public boolean isMessageDisplayed() {
        try {
            return messageText.isDisplayed();
        } catch (NoSuchElementException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    public void navigateToChangePasswordPage() {
        accountLink.click();
        securityLink.click();
        changePasswordLink.click();
    }

    public void navigateToPaymentOptionPage() {
        accountLink.click();
        orderLink.click();
        PaymentLink.click();
    }

    public void fillOutChangePasswordForm(String currentPassword, String newPassword, String newPasswordRepeat) {
        currentPasswordField.sendKeys(currentPassword);
        newPasswordRepeatField.sendKeys(newPassword);
        newPasswordRepeatField.sendKeys(newPasswordRepeat);
    }

    public void doSubmitChangePassword() {
        changeButton.click();
    }

    public String getMessageConfirmation() {
        return messageConfirmation.getText();
    }

    public void fillOutPaymentOptionsForm(String name, String cardNumber, String expiryMonth, String expiryYear) {
        nameCardField.sendKeys(name);
        numberCardField.sendKeys(cardNumber);
        expiryMonthField.sendKeys(expiryMonth);
        expiryYearField.sendKeys(expiryYear);
    }

    public void doSubmitPaymentPassword() {
        submitButton.click();
    }

    public String getCardMessageConfirmation() {
        return messageCardConfirmation.getText();
    }


}
