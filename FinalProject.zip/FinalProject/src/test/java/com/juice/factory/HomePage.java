package com.juice.factory;

public class HomePage {

}
