package com.juice.factory;

public class CheckoutPage {

    // Object repository

    // constructor with PageFactory for initiate all the page objects

    // actions or functions that require the automation process
}
