package com.juice.factory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CheckoutPage {

    // Object repository
    WebDriver driver;

    @FindBy(xpath = "//button[@routerlink='/search']")
    private WebElement searchLink;

    @FindBy(id = "checkoutButton")
    private WebElement checkoutButton;

    @FindBy(xpath = " //mat-radio-button[@aria-label='Credit Card']")
    private WebElement creditCardButton;

    // Object repository
    @FindBy(xpath = "//a[@href='#/register']")
    private WebElement registerLink;
    // constructor with PageFactory for initiate all the page objects
    public CheckoutPage(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    public void clickAddressLink() {
        searchLink.click();
    }

    // actions or functions that require the automation process
}
