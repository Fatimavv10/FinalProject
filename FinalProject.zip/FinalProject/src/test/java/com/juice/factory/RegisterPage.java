package com.juice.factory;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegisterPage {

    WebDriver driver;

    // Object repository
    @FindBy(xpath = "//a[@href='#/register']")
    private WebElement registerLink;

    @FindBy(id = "emailControl")
    private WebElement emailField;

    @FindBy(id = "passwordControl")
    private WebElement passwordField;

    @FindBy(id = "repeatPasswordControl")
    private WebElement repasswordField;

    @FindBy(id = "mat-select-12")
    private WebElement securityQuestionField;

    @FindBy(id = "securityAnswerControl")
    private WebElement securityAnswerField;

    @FindBy(id = "register-button")
    private WebElement registerButton;

    @FindBy(xpath = "//span[@class='mat-simple-snack-bar-content']")
    private WebElement messageText;

    // constructor
    public RegisterPage(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    // methods
    public void goToRegisterPage() {
        registerLink.click();
    }

    public void fillOutRegisterForm(String email, String pass, String repass, String question, String answer) {
        emailField.sendKeys(email);
        passwordField.sendKeys(pass);
        repasswordField.sendKeys(repass);
        securityQuestionField.sendKeys(question);
        securityAnswerField.sendKeys(answer);
    }

    public void sendDataForNewAccount() {
        registerButton.submit();
    }

    public boolean isRegisterSuccessPageDisplayed() {
        try {
            return messageText.isDisplayed();
        } catch (NoSuchElementException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    public String getMessage() {
        return messageText.getText();
    }

}
